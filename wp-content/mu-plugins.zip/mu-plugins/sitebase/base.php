<?php
/*
Plugin Name:  Site Specific Functionality
Description:  Custom post types, taxonomies, metaboxes, shortcodes etc
*/

require_once(dirname(__FILE__) . '/lib/post-types.php');
require_once(dirname(__FILE__) . '/lib/meta-boxes.php');
//require_once(dirname(__FILE__) . '/lib/term-meta.php');
# README #

##This is an mu-plugin which contains the metabox and custom post type config files. 

* meta-boxes.php config setup for use with Rilwis Metabox plugin
* post-types.php to setup Custom Post Types and Taxonomies
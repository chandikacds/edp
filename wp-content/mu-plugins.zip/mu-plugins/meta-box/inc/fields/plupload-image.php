<?php
/**
 * Image upload field which uses plupload library to drag and drop files to upload.
 */
class RWMB_Plupload_Image_Field extends RWMB_Image_Upload_Field {}
